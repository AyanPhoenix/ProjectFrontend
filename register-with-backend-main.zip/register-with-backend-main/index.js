const express = require("express");
const mongoose = require("mongoose");
var cors = require("cors"); // to give access to the api

const app = express();
const port = 3000;

// mongodb connection
mongoose
  .connect("mongodb://localhost:27017/UserDB")
  .then(() => {
    console.log("Connected to MongoDB");
  })
  .catch((err) => {
    console.error("Error connecting to MongoDB:", err);
  });

// database config
const userSchema = new mongoose.Schema({
  username: String,
  email: String,
  password: String,
});
const User = mongoose.model("User", userSchema);

// middlewares
app.use(express.json());
app.use(cors());

// endpoints
app.post("/register", (req, res) => {
  const userData = req.body;

  User.create(userData)
    .then(() => {
      console.log(userData.username, "added");
      return res.status(201).json(`${userData.username} added`);
    })
    .catch((err) => console.log(err));
});

// listening the app in the port
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
